import React from "react";
// @material-ui/core components
import { makeStyles } from "@material-ui/core/styles";
// core components
import Quote from "components/Typography/Quote.js";
import Muted from "components/Typography/Muted.js";
import Primary from "components/Typography/Primary.js";
import Info from "components/Typography/Info.js";
import Success from "components/Typography/Success.js";
import Warning from "components/Typography/Warning.js";
import Danger from "components/Typography/Danger.js";
import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardBody from "components/Card/CardBody.js";
import terra1 from "views/Typography/images/terra1.png"
import terra2 from "views/Typography/images/terra2.png"
import terra3 from "views/Typography/images/terra3.png"
import terra4 from "views/Typography/images/terra4.png"
import terra5 from "views/Typography/images/terra5.png"
const styles = {
  typo: {
    paddingLeft: "25%",
    marginBottom: "40px",
    position: "relative"
  },
  note: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    bottom: "10px",
    color: "#c0c1c2",
    display: "block",
    fontWeight: "400",
    fontSize: "13px",
    lineHeight: "13px",
    left: "0",
    marginLeft: "20px",
    position: "absolute",
    width: "260px"
  },
  cardCategoryWhite: {
    color: "rgba(255,255,255,.62)",
    margin: "0",
    fontSize: "14px",
    marginTop: "0",
    marginBottom: "0"
  },
  cardTitleWhite: {
    color: "#FFFFFF",
    marginTop: "0px",
    minHeight: "auto",
    fontWeight: "300",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    marginBottom: "3px",
    textDecoration: "none"
  }
};

const useStyles = makeStyles(styles);


export default function TypographyPage() {
  const classes = useStyles();
  return (
    <Card>
      <CardHeader color="primary">
        <h4 className={classes.cardTitleWhite}>Intro to Terraform</h4>
        <p className={classes.cardCategoryWhite}>
          A guide on how Terraform will be used to create virtual envionrments of your choice for the cloud provider of your choice
        </p>
      </CardHeader>
      <CardBody>
        <div className={classes.typo}>
          <div className={classes.note}></div>
          <h3>Installing Terraform</h3>
        </div>
        <div className={classes.typo}>
          <div className={classes.note}></div>
          <p>
            1. Navigate to <a href="https://www.terraform.io/">https://www.terraform.io/</a> and install the client. Extract the executable into a folder called ‘Terraform’ on your drive.
          </p>
          <p>
            2. Next, add Terraform to your path (Windows). This can be found by opening up settings, and typing Environment, then selecting “edit the system environment variables”. Next, click on Environment Variables, and edit the one called ‘Path’, adding the path to your Terraform folder. Select ‘ok’. To test that Terraform is successfully installed, run 
            ‘Terraform version’ in Powershell.
          </p>
          <p>
            3. Next, we need to download the Azure CLI. For windows, you can find it here: <a href="https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-windows?tabs=azure-cli ">https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-windows?tabs=azure-cli</a>
            Once this is complete, run ‘az login’ in powershell, and login to your account.
          </p>
          <p>
            4. If you’re using VSCode, you may have to open up Bash in Cloud Shell in order to run resources.
          </p>
        </div>
        <div className={classes.typo}>
          <div className={classes.note}></div>
          <h3>Terraform Commands</h3>
        </div>        
        <div className={classes.typo}>
          <div className={classes.note}></div>
          <ul>
            <li>Terraform apply</li>
            <ul>   
                <li>This command will read your *.tf files and apply the terraform code to the cloud provider you have specified </li>
            </ul>
            <li>Terraform plan</li>
            <ul>   
                <li>If you only want to run a plan to see what changes terraform will do </li>
            </ul>
            <li>Terraform init</li>
            <ul>   
                <li>Every time you add a new module, a provider, or the first time you want to use terraform within a project directory </li>
            </ul>
            <li>Terraform destroy</li>
            <ul>   
                <li>When you want to clean up all the resources you have created within a demo </li>
            </ul>
            <li>Terraform help</li>
            <ul>   
                <li>To get a full list of commands </li>
            </ul>                                          
          </ul>
        </div>
        <div className={classes.typo}>
          <div className={classes.note}></div>
          <h5>Importing resources from Azure into Terraform</h5>
        </div>
        <div className={classes.typo}>
          <div className={classes.note}></div>
          <ul>
            <li>Example: Resource group ‘terraform import {'<Terraform Resource Name>.<Resource Label> <Azure Resource ID>'}’Here is what an Azure VM would look like in Terraform. Note all of the variables you might want to change, such as the name, location, resource group, OS image, etc.</li>
            <img src= {terra1} >
              </img>
          </ul>
        </div> 
        <div className={classes.typo}>
          <div className={classes.note}></div>
          <h5>Overview of Starter Files for Terraform</h5>
        </div>
        <div className={classes.typo}>
          <div className={classes.note}></div>
          <p>
            Files can be found here <a href="https://bitbucket.org/ProfessionalSquid/terraform-scripts/src/master/%22%3E">https://bitbucket.org/ProfessionalSquid/terraform-scripts/src/master/%22%3E</a>
          </p>
          <ol>
            <li>Main.tf is the file that allocates the resource group and provider. The first thing you should do is run terraform init to initialize the backend for the provider. If you want to change provider (ex. AWS), you must rerun the command terraform init. </li>
            <img src= {terra2} ></img>
            <li>Vars.tf defines the main variables used throughout the other files, most notably the location variable and the global prefix used for naming.</li>
            <img src={terra3} ></img>
            <li>Instance.tf is the file where we allocate specific information regarding the VM, Network Interface, and Public IP. Note that there are comments placed that show you where to make changes regarding OS image and SSH Keys.</li>
            <img src={terra4}></img>
            <li>Network.tf defines the Virtual Network, Subnet, and Network Security Group. Note that you can modify the security rules for Inbound/Outbound ports.</li>
            <img src={terra5}></img>
            <li>Terraform.tfstate is used to store information about your managed infrastructure and configuration. This state is used by Terraform to map real world resources to your configuration, keep track of metadata, and to improve performance for large infrastructures. For all practical purposes, this file should not be modified.</li>
          </ol>
        </div> 
        <div className={classes.typo}>
          <div className={classes.note}></div>
          <h5>Deploying Terraform Infrastructure</h5>
          
          <p>There are 3 resource group options we can deploy:<br></br>
           <ul>
             1. MoodleDev resource group <br></br>
             2. NMap Scanning Lab resource group <br></br>
             3. Packet Analysis resource group <br></br>
             </ul>
             Each of these are included in the scripts listed <a href= "https://bitbucket.org/ProfessionalSquid/terraform-scripts/src/master/"> here </a>
             <br></br>Note: Please make sure you have installed the prerequisites listed in “Installing Terraform” <br></br>
                  In order to deploy these resources to your subscription, follow these steps:
              <ul>
            1. Open VSCode (or a similar environment) <br></br>
            2. Navigate your way to the correct folder that holds the Terraform scripts, and change directory into the appropriate resource group you wish to deploy <br></br>
            3. Run terraform init <br></br>
            4. If you wish to change credentials for your machine, navigate to the ‘instance.tf’ file, and alter the variables ‘admin_username’ and/or ‘admin_password’. <br></br>
               <ul>Note: If you change the username parameter, be sure to include this change in the ‘path’ variable located within the ‘ssh_keys’ block. </ul><br></br>
            5. Run terraform plan. Ensure that the files can compile without error. <br></br>
            6. Run terraform apply. Double check that no errors appear. <br></br>
            <ul>Note: Upon creating a Kali Linux instance, an error may appear saying that the Custom image requires Plan information in the request. If this appears, navigate to this <a href = "https://discuss.hashicorp.com/t/issue-creating-linux-vm-using-kali-linux-custom-image/19344"> thread </a> for help.
            </ul> <br></br>
            7. To remove these resources, run terraform destroy. <br></br>
              </ul>
          </p>
        <div className={classes.note}></div>
        <h6>Creating SSH Keys</h6>
          <p>If you wish to access your machines without the use of password authentication, then SSH is the most secure option available. If you are using MacOS or Linux, a simple ssh-keygen will suffice (see SSH into resource). However, if you are using Windows, this is the guide for you!</p> <br></br>
          1. First, download PuTTY: <a href= "https://www.putty.org/">download</a>   <br></br>
          2. Next, download PuTTYgen: <a href= "https://www.puttygen.com/">download</a> <br></br>
          3. Within PuTTYgen, generate a Public/Private key pair.  <br></br>
          <ul>Save the public key as “mykey.pub” in the folder containing the terraform scripts. </ul>
          <ul>Save the private key as “mykey” in the same folder. This can optionally be password protected, and will automatically be saved as a .ppk file. </ul>
          <ul>Click Conversions, then Export OpenSSH Key. This is actually the key we use in MacOS and Linux. Save this as “mykey.pem”. </ul>
          4.Within PuTTY:<br></br>
            <ul>Follow the path Connection--SSH--Auth, click Browse, and select “mykey” private key. </ul>
            <ul>Once loaded, you can return to the Session tab, and type in the username followed by ‘@’ followed by the IP address to the VM you wish to connect, and ensure that the port is 22. (Ex. demo@1.2.3.4) This username should match the ‘admin_username’ field populated from the instance.tf file. </ul> 
        </div>                              
        
      </CardBody>
    </Card>
  );
}
