import React from "react";
// @material-ui/core components
import { makeStyles } from "@material-ui/core/styles";
// core components
import GridItem from "components/Grid/GridItem.js";
import GridContainer from "components/Grid/GridContainer.js";
import Table from "components/Table/Table.js";
import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardBody from "components/Card/CardBody.js";
import FormDialog from "views/TableList/FormDialog.js"
const styles = {
  cardCategoryWhite: {
    "&,& a,& a:hover,& a:focus": {
      color: "rgba(255,255,255,.62)",
      margin: "0",
      fontSize: "14px",
      marginTop: "0",
      marginBottom: "0"
    },
    "& a,& a:hover,& a:focus": {
      color: "#FFFFFF"
    }
  },
  cardTitleWhite: {
    color: "#FFFFFF",
    marginTop: "0px",
    minHeight: "auto",
    fontWeight: "300",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    marginBottom: "3px",
    textDecoration: "none",
    "& small": {
      color: "#777",
      fontSize: "65%",
      fontWeight: "400",
      lineHeight: "1"
    }
  }
};

const rows = [
  [
    'NMAP Scanning and Identification',
    "This exercise will go over the basic fundamentals of utilizing NMap to conduct a scan against a Windows and an Ubuntu machine. It will also cover how to identify the differences in network traffic, utilizing Wireshark.",
     15,
     3,
    36.38,
   <FormDialog/>
],
  [
    'Packet Analysis',
    "This exercise will help the fundamentals of Packet analysis",
     15,
     1,
     36.38,
     <FormDialog/>
  ]


];
const useStyles = makeStyles(styles);

export default function TableList() {
  const classes = useStyles();
  return (
    <GridContainer>
      <GridItem xs={12} sm={12} md={12}>
        <Card>
          <CardHeader color="primary">
            <h4 className={classes.cardTitleWhite}>Available Courses from the CRL team</h4>
            <p className={classes.cardCategoryWhite}>
              Once a you want to purchase a course you should enroll into the course on moodle
            </p>
          </CardHeader>
          <CardBody>
            <Table
              tableHeaderColor="primary"
              tableHead={["Course","Course Information", "Maximum Students", "Amount of VMs", "Price","Checkout"]}
              tableData = {rows}
            />
          </CardBody>
        </Card>
      </GridItem>
      <GridItem xs={12} sm={12} md={12}>
        <Card>
          <CardHeader color="primary">
            <h4 className={classes.cardTitleWhite}>After Purchasing and Dowloading the zip to deploy</h4>  
          </CardHeader>
          <CardBody>
          <div className={classes.typo}>
          <div className={classes.note}></div>
          <h5>Deploying Terraform Infrastructure</h5>
          
          <p>There are 3 resource group options we can deploy:<br></br>
           <ul>
             1. MoodleDev resource group <br></br>
             2. NMap Scanning Lab resource group <br></br>
             3. Packet Analysis resource group <br></br>
             </ul>
             Each of these are included in the scripts listed <a href= "https://bitbucket.org/ProfessionalSquid/terraform-scripts/src/master/"> here </a>
             <br></br>Note: Please make sure you have installed the prerequisites listed in “Installing Terraform” <br></br>
                  In order to deploy these resources to your subscription, follow these steps:
              <ul>
            1. Open VSCode (or a similar environment) <br></br>
            2. Navigate your way to the correct folder that holds the Terraform scripts, and change directory into the appropriate resource group you wish to deploy <br></br>
            3. Run terraform init <br></br>
            4. If you wish to change credentials for your machine, navigate to the ‘instance.tf’ file, and alter the variables ‘admin_username’ and/or ‘admin_password’. <br></br>
               <ul>Note: If you change the username parameter, be sure to include this change in the ‘path’ variable located within the ‘ssh_keys’ block. </ul><br></br>
            5. Run terraform plan. Ensure that the files can compile without error. <br></br>
            6. Run terraform apply. Double check that no errors appear. <br></br>
            <ul>Note: Upon creating a Kali Linux instance, an error may appear saying that the Custom image requires Plan information in the request. If this appears, navigate to this <a href = "https://discuss.hashicorp.com/t/issue-creating-linux-vm-using-kali-linux-custom-image/19344"> thread </a> for help.
            </ul> <br></br>
            7. To remove these resources, run terraform destroy. <br></br>
              </ul>
          </p>
          </div>
          </CardBody>
        </Card>
      </GridItem>
    </GridContainer>
  );
}
