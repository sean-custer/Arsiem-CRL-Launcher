import React, {useState} from "react";
// @material-ui/core components
import { makeStyles } from "@material-ui/core/styles";
// core components
import GridItem from "components/Grid/GridItem.js";
import GridContainer from "components/Grid/GridContainer.js";
//import Table from "components/Table/Table.js";
import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardBody from "components/Card/CardBody.js";
import Table from "@material-ui/core/Table";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import Button from "components/CustomButtons/Button.js";
import axios from "axios"
const styles = {
  cardCategoryWhite: {
    "&,& a,& a:hover,& a:focus": {
      color: "rgba(255,255,255,.62)",
      margin: "0",
      fontSize: "14px",
      marginTop: "0",
      marginBottom: "0"
    },
    "& a,& a:hover,& a:focus": {
      color: "#FFFFFF"
    }
  },
  cardTitleWhite: {
    color: "#FFFFFF",
    marginTop: "0px",
    minHeight: "auto",
    fontWeight: "300",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    marginBottom: "3px",
    textDecoration: "none",
    "& small": {
      color: "#777",
      fontSize: "65%",
      fontWeight: "400",
      lineHeight: "1"
    }
  }
};

const useStyles = makeStyles(styles);

export default function MoodleLogin () {
  const classes = useStyles();

  
    const[resource,setResource] = React.useState([]);
    React.useEffect(() => {
        const fetchData = async() => {
            const response = await axios.get('https://api-for-guacips.azure-api.net/api-for-ipaddress/manual/paths/invoke');
            console.log(response.data);
            setResource(response.data);
        };
        fetchData();
    },[]);
  function submitOff(name){
    axios.post(`https://api-for-guacips.azure-api.net/turn-off/manual/paths/invoke?name=${name}`).then(function(response){
      console.log(response);
    }).catch(function(error){
      console.log(error);
    });
  
  }
  function submitOn(name){
    console.log(name)
    axios.post(`https://api-for-guacips.azure-api.net/turn-on/manual/paths/invoke?name=${name}`).then(function(response){
      console.log(response);
    }).catch(function(error){
      console.log(error);
    });
    
  }  
  
  return (
    <GridContainer>
      <GridItem xs={12} sm={12} md={12}>
        <Card>
          <CardHeader color="primary">
            <h4 className={classes.cardTitleWhite}>Virtual Enviornment Login Page</h4>
            <p className={classes.cardCategoryWhite}>
              According to the Resource Group specified by your instructor click on the according link
            </p>
          </CardHeader>
          <CardBody>
            <Table className={classes.table}>
                <TableHead>
                    <TableRow>
                        <TableCell >Resource Group Name</TableCell>
                        <TableCell >Virtual Environment Status</TableCell>
                        <TableCell>Virtual Environment Link</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {resource.map((resources) =>(
                        <TableRow>
                            <TableCell >{resources.Name}</TableCell>
                            <TableCell >{resources.status}</TableCell>
                            <TableCell> {<a href = {"http://"+ resources.ip_add +":8080/guacamole/#/" } >Enter Portal </a> } </TableCell>
                            <TableCell>
                              <Button
                              //value = {resources.Name}
                              onClick={() => submitOn(resources.Name)}
                              varient="contained"
                              color="primary">
                              Turn On</Button>
                            </TableCell>
                            <TableCell>
                              <Button
                              //value = {resources.Name}
                              onClick={() => submitOff(resources.Name)}
                              varient="contained"
                              color="primary">
                              Turn Off</Button>
                            </TableCell>                            
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
          </CardBody>
        </Card>
      </GridItem>
      
    </GridContainer>
  );
}
