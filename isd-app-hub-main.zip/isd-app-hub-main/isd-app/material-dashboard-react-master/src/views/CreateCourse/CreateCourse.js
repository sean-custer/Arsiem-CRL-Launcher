import React from "react";
// @material-ui/core components
import { makeStyles } from "@material-ui/core/styles";
import InputLabel from "@material-ui/core/InputLabel";
import Slider from "@material-ui/core/Slider";
import Input from "@material-ui/core/Input";
import axios from "axios"
// core components
import GridItem from "components/Grid/GridItem.js";
import GridContainer from "components/Grid/GridContainer.js";
import CustomInput from "components/CustomInput/CustomInput.js";
import Button from "components/CustomButtons/Button.js";
import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardAvatar from "components/Card/CardAvatar.js";
import CardBody from "components/Card/CardBody.js";
import CardFooter from "components/Card/CardFooter.js";
import avatar from "assets/img/faces/marc.jpg";
import { Typography } from "@material-ui/core";

const styles = {
  cardCategoryWhite: {
    color: "rgba(255,255,255,.62)",
    margin: "0",
    fontSize: "14px",
    marginTop: "0",
    marginBottom: "0"
  },
  cardTitleWhite: {
    color: "#FFFFFF",
    marginTop: "0px",
    minHeight: "auto",
    fontWeight: "300",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    marginBottom: "3px",
    textDecoration: "none"
  }
};

const useStyles = makeStyles(styles);

export default function CreateCourse() {
  const [value, setValue] = React.useState(30);
  const handleSliderChange = (event, newValue) => {
    setValue(newValue);
  };

  const handleInputChange = (event) => {
    setValue(event.target.value === '' ? '' : Number(event.target.value));
  };

  function submitStudent() {
    axios.post('http://localhost:5000/api/submit', {data: value,}).then(function(response){
      console.log(response);
    }).catch(function(error){
      console.log(error);
    });
    console.log(value)
  }
  const classes = useStyles();
  return (
    <div>
      <GridContainer>
        <GridItem xs={12} sm={12} md={20}>
          <Card>

            <CardBody>
              <Typography>
                How many students would you like to clone lab instances for?
              </Typography>
              <GridContainer>

                <GridItem xs={12} sm={12} md={5}>
                  <Slider
                    value={typeof value === 'number' ? value : 0}
                    onChange={handleSliderChange}
                    aria-labelledby="input-slider"
                    max={50}
                  /> 
                </GridItem>
                <GridItem>
                  <Input
                  value={value}
                  margin="dense"
                  onChange={handleInputChange}
                  inputProps={{
                    step:10,
                    min:0,
                    max:50,
                    type: 'number',
                    'aria-labelledby': 'input-slider',
                  }}
                  />
                </GridItem>
                <GridItem>
                  <Button 
                  onClick={submitStudent}
                  varient="contained"
                  color="primary"
                  >
                    SUBMIT</Button>
                </GridItem>
              </GridContainer>
            </CardBody>
            <CardFooter>
              
            </CardFooter>
          </Card>
        </GridItem>
      </GridContainer>
    </div>
  );
}
