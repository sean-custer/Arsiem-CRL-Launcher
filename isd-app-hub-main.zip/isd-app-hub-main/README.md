# ISDapp

Live at http://arsiem-isd-app.azurewebsites.net/admin/table

# Pushing Changes to the Repo

### 1) Add the remote repository

git remote add repo-name git@github.com:sam-edwards99/isd-app-hub.git
  
repo-name can be whatever you want it to be.  
  
 ex:
 git remote add prod git@github.com:sam-edwards99/isd-app-hub.git
  
### 2) Make sure your local changes are commited

git status

git add ...

git commit ...

### 3) Push your changes

git push repo-name branch-name
  
repo-name must be same as in step 1.
  
branch-name can be anything you want.
I'd recommend using the same branch name as your local git branch.
  
### 4) Check that you commit has been pushed to the GitHub branch

Go to this Repo Github page, check the branch you just pushed and verify your changes.

### 5) Merge Request

Click the Merge Request button and merge your branch into the main branch

### 6) Actions

Open the Actions Tab and watch the pipeline try and run the new build. 
If there are any errors, you will see them in the latest action.

### 7) Verify your changes

Go to the website link and verify that your changes work and identify any bugs.



